#include <stdio.h>
#include <stdlib.h>
#include <err.h>

int add(int a, int b)
{
	printf("a + b = %d\n", a+b);
	return 0;
}

int subtract(int a, int b)
{
	printf("a - b = %d\n", a-b);
	return 0;
}

int def_err(int a, int b)
{
	printf("Incorrect op for %d and %d\n", a, b);
	return 0;
}

int main(int argc, char *argv[])
{
	int a = 0, b = 0;
	char op;
	int (*fp)(int, int);

	if (argc != 4) {
		puts("Incorrect arguments.\nUSE: ./func_pointer <num> <op> <num>");
		exit(EXIT_FAILURE);
	}

	a = strtol(argv[1], NULL, 10);
	b = strtol(argv[3], NULL, 10);

	switch(argv[2][0]) {
	case '+':
		fp = add;
		break;
	case '-':
		fp = subtract;
		break;
	default:
		fp = def_err;
		break;
	}

	fp(a, b);

	return 0;
}
