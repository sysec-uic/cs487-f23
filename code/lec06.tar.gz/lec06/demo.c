#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <err.h>

#define	SIZE	64

#if 1
void empty()
{
	system("/bin/ls");
}
#endif

int vul(char *input)
{
	int flag = 0;
	char buf[SIZE];
	strcpy(buf, input);
	if (flag) {
		printf("Congrats! Flag was changed!\n");
	} else {
		printf("Flag was not changed. Try it again!\n");
	}
	return 0;
}

int main(int argc, char *argv[], char *env[])
{
	if(argc == 1) {
		errx(1, "Please specify an argument.");
	}
	vul(argv[1]);

	return 0;
}
