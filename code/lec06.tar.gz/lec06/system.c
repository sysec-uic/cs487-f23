#include <stdlib.h>

int main(int argc, char *argv[])
{
    //system("/bin/sh");
    system("sh");
}
