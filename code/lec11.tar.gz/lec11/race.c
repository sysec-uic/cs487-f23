#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>

int gen_new_passwd() {
  int passwd = 0;
  FILE *fd = fopen("/dev/random", "r");
  if (!fd) err(1, "Failed to open /dev/random");

  fread(&passwd, 1, sizeof(passwd), fd);
  fclose(fd);

  printf("[!] Generate a new passwd");
  fflush(stdout);

  for (int i = 0; i < 10; i++) {
    printf("."); usleep(300000); fflush(stdout);
  }
  printf("Ready!\n");

  return passwd;
}

void save_passwd_into_vault(int passwd) {
  char tmpfile[100];
  snprintf(tmpfile, sizeof(tmpfile), "/tmp/.lock-%d", getpid());
  if (access(tmpfile, F_OK) != -1) {
    printf("the lock file exists, please first clean up\n");
    exit(1);
  }

  FILE *fp = fopen(tmpfile, "w");
  if (!fp)
    err(1, "failed to create %s", tmpfile);
  fprintf(fp, "%d", passwd);
  fclose(fp);

  /* DELETED! */
  unlink(tmpfile);
}

void pw() {
  char buf[32];
  int passwd = gen_new_passwd();
  save_passwd_into_vault(passwd);

  printf("Password:");
  scanf("%31s", buf);

  if (atoi(buf) == passwd) {
    printf("Password OK :)\n");
  } else {
    printf("Invalid Password!\n");
  }
}

int main(int argc, char *argv[])
{
  pw();
  return 0;
}
