#include <stdio.h>

int main(int argc, char* argv[])
{
    int a = 0x12345678;
    int b = 0xef345678;
    unsigned int sum = a+b;
    printf("a=%d, b=%d, sum=%u\n", a, b, sum);
    return 0;
}
