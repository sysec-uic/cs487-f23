#include <stdio.h>

int main(int argc, char* argv[])
{
    int i = 0x12345678;
    short s = i;
    char c = i;

    printf("i=0x%x(%d), s=0x%x(%d), c=0x%x(%d)\n", i, i, s, s, c, c);

    return 0;
}
