Hints:

## Still here
I'll let you in on a secret: that useful string "/bin/cat flag.txt" is still present in this binary, as is a call to system(). It's just a case of finding them and chaining them together to make the magic happen.

## Treasure hunting
Don't just take my word for it, let's check the call to system() and that useful string are actually here. Afterall if I hadn't mentioned that they were still there how would you know where to start? Go ahead and use rabin2 or any of the tools mentioned in the Beginners' guide to locate useful strings and note their location. Now ensure that system() is imported, rabin2 or readelf are here to help.

## All together now
Now that you've gathered the elements of your exploit you can start to piece them together, you want to call system() with the "/bin/cat flag.txt" string as the only argument. You'll also have to start dealing with the differences between the various architectures' calling conventions.

## Finish the job
Once you've planned your chain, craft a suitable solution. We're still trying to read the contents of the flag.txt file on the imaginary remote machine. You can do the x86 challenge with just a 2 link chain and the x86_64 challenge with a 3 link chain.
