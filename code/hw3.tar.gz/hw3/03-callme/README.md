Hint:

## Procedure Linkage
The Procedure Linkage Table (PLT) is used to resolve function addresses in
imported libraries at runtime, it's worth reading up about it. See Appendix A
in the Beginners' guide for a brief explanation of how the PLT is used in lazy
binding. Even better, go ahead and step through the lazy linking process in a
debugger.

You must call the callme_one(), callme_two() and callme_three() functions 
in that order, each with the arguments 0xdeadbeef, 0xcafebabe, 0xd00df00d
e.g. callme_one(0xdeadbeef, 0xcafebabe, 0xd00df00d) to print the flag. For the
x86_64 binary double up those values, e.g. callme_one(0xdeadbeefdeadbeef,
0xcafebabecafebabe, 0xd00df00dd00df00d)

The solution here is simple enough, use your knowledge about what resides in the PLT to call the callme_ functions in the above order and with the correct arguments. If you're taking on the MIPS version of this challenge, don't forget about the branch delay slot.

Don't get distracted by the incorrect calls to these functions made in the binary, they're there to ensure these functions get linked. You can also ignore the .dat files and encrypted flag in this challenge, they're there to ensure the functions must be called in the correct order.


