#include <stdio.h>

int main(int argc, char *argv[], char *envp[])
{
    printf("argv[0]: %s\n", argv[0]);
    printf("envp[0]: %s\n", envp[0]);
    return 0;
}
