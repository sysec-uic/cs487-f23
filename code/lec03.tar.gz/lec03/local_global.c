#include <stdio.h>
#include <stdlib.h>

char g_i[] = "Initialized global variable\n";
char* g_u;

int main(int argc, char *argv[]) {
  int l_i = 10;
  int l_u;
  void *p = malloc(8);
  printf("g_i is at %p\n", &g_i);
  printf("g_u is at %p\n", &g_u);
  printf("l_i in main() is at %p\n", &l_i);
  printf("l_u in main() is at %p\n", &l_u);
  printf("memory from malloc() is at %p\n", p);
  free(p);
}
