#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  char *argv0[] = {"/bin/id", NULL, NULL};
  char *argv1[] = {"/bin/sh", NULL};
  execve(argv0[0], argv0, NULL);
  execve(argv1[0], argv1, NULL);
  return 0;
}
