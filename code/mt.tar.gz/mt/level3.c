#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BANNER \
	"===================================\n"\
	"A buggy cat (file viewer) for CS487\n"\
	"===================================\n"

#define	SIZE	512

int print_content(char *input)
{
	int flag = 0;
	char buf[SIZE];

	strcpy(buf, input);
	fprintf(stdout, "%s\n%s", BANNER, buf);

	return 0;
}

int main(int argc, char* argv[], char* env[]) {
	FILE *fd;
	char input[1024];
	int len = 0;

	if (argc != 2) {
		errx(1, "Please specify an argument of file name.");
	}

	fd = fopen(argv[1], "rb");
	if (fd == NULL) {
		errx(1, "File not found.");
	}
	len = fread(input, sizeof(char), 1024, fd);

	print_content(input);

	return 0;
}
