#include <stdio.h>
#include <stdlib.h>

void fly() {
  printf("Flying ...\n");
}

void win() {
  printf("You got the flag!\n");
}

typedef struct airplane {
  char name[20];
  void (*pfun)();
} airplane;

int main()
{
  printf("fly() at %p; win() at %p\n", fly, win);

  struct airplane *p1 = malloc(sizeof(airplane));
  printf("Airplane1 is at %p\n", p1);
  struct airplane *p2 = malloc(sizeof(airplane));
  printf("Airplane2 is at %p\n", p2);
  p1->pfun = fly;
  p2->pfun = fly;

  fgets(p2->name, 10, stdin);
  // overflow a heap buffer
  fgets(p1->name, 50, stdin);

  p1->pfun();
  p2->pfun();

  free(p1);
  free(p2);

  return 0;
}
