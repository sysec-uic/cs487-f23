#include <stdio.h>
#include <stdlib.h>

void fly() {
  printf("Flying ...\n");
}

void win() {
  printf("You got the flag!\n");
}

typedef struct airplane {
  void (*pfun)();
  char name[20];
} airplane;

typedef struct car {
  int volume;
  char name[20];
} car;

int main()
{
  printf("fly() at %p; win() at %p (%u)\n", fly, win, (unsigned int)win);

  struct airplane *p = malloc(sizeof(airplane));
  printf("Airplane is at %p\n", p);
  p->pfun = fly;
  p->pfun();
  free(p);

  struct car *p1 = malloc(sizeof(car));
  printf("Car is at %p\n", p1);

  int volume;
  printf("What is the volume of the car?\n");
  scanf("%u", &volume);
  p1->volume = volume;

  // dangling pointer
  p->pfun();
  free(p);

  return 0;
}
